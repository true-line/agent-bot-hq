// Interim artifact entrypoint: verify vendored contracts without network fallback.
if (process.platform !== 'darwin') throw new Error('interim artifact runs on macOS only');
process.env.HQ_INTERIM_OFFLINE = '1';
await import('./interim-core.mjs');
